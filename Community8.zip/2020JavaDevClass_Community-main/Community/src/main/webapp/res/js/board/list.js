function goToDetail (boardPk) {
	location.href = `/board/detail?boardPk=${boardPk}`
}