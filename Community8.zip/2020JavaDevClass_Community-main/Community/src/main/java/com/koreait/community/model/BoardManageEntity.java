package com.koreait.community.model;

import org.apache.ibatis.type.Alias;

public class BoardManageEntity {
	private int category;
	private String nm;
	private int orderby;
	
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public int getOrderby() {
		return orderby;
	}
	public void setOrderby(int orderby) {
		this.orderby = orderby;
	}	
}
