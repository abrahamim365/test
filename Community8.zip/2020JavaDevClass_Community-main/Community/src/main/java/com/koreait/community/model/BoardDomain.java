package com.koreait.community.model;

public class BoardDomain extends BoardEntity {
	private String writerNm;

	public String getWriterNm() {
		return writerNm;
	}

	public void setWriterNm(String writerNm) {
		this.writerNm = writerNm;
	}
}
