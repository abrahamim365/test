package com.koreait.community;

import java.util.List;

import com.koreait.community.model.BoardManageEntity;

public class Const {
	public static List<BoardManageEntity> menus = null;
	
	public static final String KEY_LOGINUSER = "loginUser";
	public static final String KEY_LIST = "list";
	public static final String KEY_DATA = "data";
	public static final String KEY_MENULIST = "menuList";
}
